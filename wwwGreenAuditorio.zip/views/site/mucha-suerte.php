
<p class="bold"><span class="primary-color">Hemos registrado tu participacion</span>, si resultas ganador nuestros equipo de promocions te contactará pormedio de tu número telefónico, <span class="highlight">!mucha suerte!</span></p>
